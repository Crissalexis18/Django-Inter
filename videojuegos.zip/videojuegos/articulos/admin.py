from django.contrib import admin
from articulos.models import Articulos, Categoria

admin.site.register(Articulos)
admin.site.register(Categoria)
